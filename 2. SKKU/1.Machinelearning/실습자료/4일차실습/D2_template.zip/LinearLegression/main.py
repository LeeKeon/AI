import csv
import numpy as np

class LinearRegression():
    def __init__(self, x, y): # 생성자
        self.x = x # 변수 초기화
        self.y = y
        self.num_data = self.x.shape[0]
        self.num_feature = self.x.shape[1]
        self.w = np.zeros((self.num_feature, 1))

    def predict(self, x):
        #################################################
        #    코드 작성
        #################################################
        return

    def train(self, lr, epoch):
        for i in range(0, epoch):
            #################################################
            #    코드 작성
            #################################################

def data_load(dana_name, tr_te):
    y = []
    x = []

    if dana_name == 'BloodPressure':
        if(tr_te == 'train'):
            file = './data/bloodPressure/train.csv'
        elif(tr_te == 'test'):
            file = './data/bloodPressure/test.csv'

        with open(file, 'r') as csvfile:
            csv_reader = csv.reader(csvfile)
            next(csv_reader)
            for row in csv_reader:
                x.append([1, float(row[0])])
                y.append([float(row[1])])

    if dana_name == 'Fish':
        if(tr_te == 'train'):
            file = './data/fish/train.csv'
        elif(tr_te == 'test'):
            file = './data/fish/test.csv'

        with open(file, 'r') as csvfile:
            csv_reader = csv.reader(csvfile)
            next(csv_reader)
            for row in csv_reader:
                x.append([1, float(row[0]), float(row[1])])
                y.append([float(row[2])])
    return np.array(x), np.array(y)

def eval(prediction, y):
    inner = np.power((prediction - y), 2)
    return np.sqrt(np.sum(inner, axis=0) / len(y))

def main():
    X_train, Y_train = data_load('BloodPressure', 'train')
    model = LinearRegression(X_train, Y_train)
    model.train(0.0, 1) # learning rate, epoch

    X_test, Y_test = data_load('BloodPressure', 'test')
    prediction = model.predict(X_test)

    rmse = eval(prediction, Y_test)
    print("%.2f"%(rmse))


    X_train, Y_train = data_load('Fish', 'train')
    model = LinearRegression(X_train, Y_train)
    model.train(0.0, 1) # learning rate, epoch

    X_test, Y_test = data_load('Fish', 'test')
    prediction = model.predict(X_test)

    rmse = eval(prediction, Y_test)
    print("%.2f"%(rmse))

if __name__ == "__main__":
    main()


